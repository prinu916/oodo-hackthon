// Sample Tickets Data
const adminTickets = [
  { id: 1, subject: "Printer Not Working", status: "Open", category: "IT", date: "2025-08-01", replies: 2, assignedTo: "Unassigned" },
  { id: 2, subject: "Salary Delay Issue", status: "In Progress", category: "HR", date: "2025-07-30", replies: 5, assignedTo: "Agent A" },
  { id: 3, subject: "Laptop Replacement", status: "Resolved", category: "IT", date: "2025-07-28", replies: 1, assignedTo: "Agent B" }
];

const agents = ["Agent A", "Agent B", "Agent C"];
let filteredAdminTickets = [...adminTickets];

document.addEventListener("DOMContentLoaded", () => {
  displayAdminTickets();
});

// Display Tickets for Admin
function displayAdminTickets() {
  const ticketList = document.getElementById("admin-ticket-list");
  ticketList.innerHTML = "";

  if (filteredAdminTickets.length === 0) {
    ticketList.innerHTML = "<p>No tickets found.</p>";
    return;
  }

  filteredAdminTickets.forEach(ticket => {
    const div = document.createElement("div");
    div.className = "ticket-card";
    div.innerHTML = `
      <h3>${ticket.subject}</h3>
      <p>Status: <strong>${ticket.status}</strong></p>
      <p>Category: ${ticket.category}</p>
      <p>Assigned To: ${ticket.assignedTo}</p>
      <small>Date: ${ticket.date} | Replies: ${ticket.replies}</small>

      <div class="ticket-actions">
        <select onchange="assignAgent(${ticket.id}, this.value)">
          <option value="">Assign Agent</option>
          ${agents.map(agent => `<option value="${agent}" ${ticket.assignedTo === agent ? 'selected' : ''}>${agent}</option>`).join("")}
        </select>
        
        <select onchange="changeStatus(${ticket.id}, this.value)">
          <option value="">Change Status</option>
          <option value="Open">Open</option>
          <option value="In Progress">In Progress</option>
          <option value="Resolved">Resolved</option>
          <option value="Closed">Closed</option>
        </select>
        
        <button onclick="deleteTicket(${ticket.id})" style="background:#dc3545; color:white;">Delete</button>
      </div>
    `;
    ticketList.appendChild(div);
  });
}

// Assign Agent
function assignAgent(ticketId, agentName) {
  const ticket = adminTickets.find(t => t.id === ticketId);
  ticket.assignedTo = agentName || "Unassigned";
  applyAdminFilters();
  alert(`Assigned ${agentName} to ticket: ${ticket.subject}`);
}

// Change Status
function changeStatus(ticketId, newStatus) {
  const ticket = adminTickets.find(t => t.id === ticketId);
  ticket.status = newStatus || ticket.status;
  applyAdminFilters();
  alert(`Ticket "${ticket.subject}" status updated to ${ticket.status}`);
}

// Delete Ticket
function deleteTicket(ticketId) {
  const index = adminTickets.findIndex(t => t.id === ticketId);
  if (confirm("Are you sure you want to delete this ticket?")) {
    adminTickets.splice(index, 1);
    applyAdminFilters();
  }
}

// Filters & Sorting
function applyAdminFilters() {
  const searchValue = document.getElementById("admin-search").value.toLowerCase();
  const statusValue = document.getElementById("admin-status-filter").value;
  const categoryValue = document.getElementById("admin-category-filter").value;
  const sortValue = document.getElementById("admin-sort-filter").value;

  filteredAdminTickets = adminTickets.filter(ticket =>
    ticket.subject.toLowerCase().includes(searchValue) &&
    (statusValue === "" || ticket.status === statusValue) &&
    (categoryValue === "" || ticket.category === categoryValue)
  );

  // Sorting
  if (sortValue === "recent") {
    filteredAdminTickets.sort((a, b) => new Date(b.date) - new Date(a.date));
  } else if (sortValue === "replied") {
    filteredAdminTickets.sort((a, b) => b.replies - a.replies);
  }

  displayAdminTickets();
}

// Logout
function logout() {
  alert("Logged out successfully!");
  window.location.href = "index.html";
}
