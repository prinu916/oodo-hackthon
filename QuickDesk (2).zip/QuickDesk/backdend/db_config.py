import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="2109",        # change if your MySQL has password
        database="quickdesk"
    )
