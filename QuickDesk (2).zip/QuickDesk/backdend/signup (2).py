from db_config import get_connection

def create_user(name, email, password, role):
    conn = get_connection()
    cursor = conn.cursor()
    query = "INSERT INTO users (name, email, password, role) VALUES (%s, %s, %s, %s)"
    cursor.execute(query, (name, email, password, role))
    conn.commit()
    conn.close()
    print("✅ User created successfully!")

def login_user(email, password):
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE email = %s AND password = %s"
    cursor.execute(query, (email, password))
    user = cursor.fetchone()
    cursor = conn.cursor()
    query = "SELECT name FROM users WHERE email = %s"
    cursor.execute(query, (email,))
    result = cursor.fetchone()
    
    if user:
        print("✅ Login successful!")
        print(f"Welcome {result[0]} !")
        return user
    else:
        print("❌ Invalid email or password.")
        return None
    
