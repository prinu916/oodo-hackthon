from models import create_user, login_user

print("🎉 Welcome to QuickDesk")

while True:
    print("\nChoose an option:")
    print("1. Create User")
    print("2. Login User")
    print("3. Exit")

    choice = input("Enter choice: ")

    if choice == '1':
        name = input("Name: ")
        email = input("Email: ")
        password = input("Password: ")
        role = input("Role (user/agent/admin): ")
        create_user(name, email, password, role)

    elif choice == '2':
        email = input("Email: ")
        password = input("Password: ")
        user = login_user(email, password)

    elif choice == '3':
        break
    else:
        print("Invalid choice.")
