// Sample Ticket Data
const ticketsData = [
  { id: 1, subject: "Printer Not Working", status: "Open", category: "IT", date: "2025-08-01", replies: 2 },
  { id: 2, subject: "Salary Delay Issue", status: "In Progress", category: "HR", date: "2025-07-30", replies: 5 },
  { id: 3, subject: "Laptop Replacement", status: "Resolved", category: "IT", date: "2025-07-28", replies: 1 },
  { id: 4, subject: "Tax Deduction Error", status: "Closed", category: "Finance", date: "2025-07-25", replies: 3 },
  { id: 5, subject: "Network Down Issue", status: "Open", category: "IT", date: "2025-07-22", replies: 4 },
  { id: 6, subject: "HR Policy Change Query", status: "Resolved", category: "HR", date: "2025-07-20", replies: 2 },
  { id: 7, subject: "Finance Report Delay", status: "Closed", category: "Finance", date: "2025-07-18", replies: 6 },
  { id: 8, subject: "Email Login Error", status: "In Progress", category: "IT", date: "2025-07-15", replies: 1 },
  { id: 9, subject: "Password Reset Required", status: "Open", category: "IT", date: "2025-07-14", replies: 2 }
];

let filteredTickets = [...ticketsData];
let currentPage = 1;
const ticketsPerPage = 3;

document.addEventListener("DOMContentLoaded", () => {
  applyFilters();
});

// Display Tickets with Pagination
function displayTickets() {
  const ticketList = document.getElementById("ticket-list");
  ticketList.innerHTML = "";

  const start = (currentPage - 1) * ticketsPerPage;
  const end = start + ticketsPerPage;
  const paginatedTickets = filteredTickets.slice(start, end);

  if (paginatedTickets.length === 0) {
    ticketList.innerHTML = "<p>No tickets found.</p>";
  } else {
    paginatedTickets.forEach(ticket => {
      const div = document.createElement("div");
      div.className = "ticket-card";
      div.onclick = () => viewTicket(ticket.id);
      div.innerHTML = `
        <h3>${ticket.subject}</h3>
        <p>Status: ${ticket.status}</p>
        <p>Category: ${ticket.category}</p>
        <small>Date: ${ticket.date} | Replies: ${ticket.replies}</small>
      `;
      ticketList.appendChild(div);
    });
  }

  updatePaginationControls();
}

// Apply Filters & Sorting
function applyFilters() {
  const searchValue = document.getElementById("search").value.toLowerCase();
  const statusValue = document.getElementById("status-filter").value;
  const categoryValue = document.getElementById("category-filter").value;
  const sortValue = document.getElementById("sort-filter").value;

  filteredTickets = ticketsData.filter(ticket =>
    ticket.subject.toLowerCase().includes(searchValue) &&
    (statusValue === "" || ticket.status === statusValue) &&
    (categoryValue === "" || ticket.category === categoryValue)
  );

  // Sorting
  if (sortValue === "recent") {
    filteredTickets.sort((a, b) => new Date(b.date) - new Date(a.date));
  } else if (sortValue === "replied") {
    filteredTickets.sort((a, b) => b.replies - a.replies);
  }

  currentPage = 1;
  displayTickets();
}

// Pagination Controls
function updatePaginationControls() {
  const pageInfo = document.getElementById("page-info");
  pageInfo.textContent = 'Page ${currentPage} of ${Math.ceil(filteredTickets.length / ticketsPerPage)}';

  document.getElementById("prevBtn").disabled = currentPage === 1;
  document.getElementById("nextBtn").disabled = currentPage === Math.ceil(filteredTickets.length / ticketsPerPage);
}

// Next/Prev Buttons
function nextPage() {
  if (currentPage < Math.ceil(filteredTickets.length / ticketsPerPage)) {
    currentPage++;
    displayTickets();
  }
}

function prevPage() {
  if (currentPage > 1) {
    currentPage--;
    displayTickets();
  }
}

// ✅ Go to Page Function
function goToPage() {
  const pageInput = document.getElementById("gotoPage").value;
  const pageNumber = parseInt(pageInput);
  const totalPages = Math.ceil(filteredTickets.length / ticketsPerPage);

  if (pageNumber >= 1 && pageNumber <= totalPages) {
    currentPage = pageNumber;
    displayTickets();
  } else {
    alert('Invalid page number! Enter between 1 and ${totalPages}.');
  }
}

// View Ticket
function viewTicket(id) {
  window.location.href = "ticket-details.html";
}

// Logout
function logout() {
  alert("Logged out successfully!");
  window.location.href = "index.html";
}